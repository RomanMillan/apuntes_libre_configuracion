const db = require('diskdb');
db.connect('../data', ['birds','monkeys']);